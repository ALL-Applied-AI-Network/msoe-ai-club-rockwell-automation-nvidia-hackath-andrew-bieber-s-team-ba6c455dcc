"""Regression checks for exported geometry, contact proxies and jaw range."""
import unittest
import numpy as np
import scene_config as C
from flat_fingers import load_stl, collider_boxes


class FlatFingerTests(unittest.TestCase):
    def test_mesh_volume_matches_collision_union(self):
        for tag in ('L', 'R'):
            boxes = collider_boxes(tag)
            for part in ('support', 'pad'):
                points, _ = load_stl(tag, part)
                triangles = np.array(points).reshape(-1, 3, 3)
                volume = abs(np.einsum('ij,ij->i', triangles[:, 0],
                             np.cross(triangles[:, 1], triangles[:, 2])).sum() / 6)
                selected = boxes[:2] if part == 'support' else boxes[2:]
                self.assertAlmostEqual(volume, sum(np.prod(b[1]) for b in selected), places=12)
                for point in points:
                    self.assertTrue(any(np.all(np.abs(np.array(point)-center) <=
                                        np.array(size)/2 + 1e-10)
                                        for _, size, center in selected))

    def test_pad_and_support_meet_without_overlap(self):
        for tag in ('L', 'R'):
            _, support_size, support_center = collider_boxes(tag)[1]
            _, pad_size, pad_center = collider_boxes(tag)[2]
            self.assertAlmostEqual(abs(support_center[1] - pad_center[1]),
                                   (support_size[1] + pad_size[1]) / 2)

    def test_actual_pad_gap_and_cube_target(self):
        for jaw, expected in ((C.JAW_OPEN, .020), (C.JAW_CLOSED, .008)):
            left = jaw + C.FINGER_WIDTH/2 - .002
            right = -jaw - C.FINGER_WIDTH/2 + .002
            self.assertAlmostEqual(left-right, expected)
        self.assertAlmostEqual(C.CUBE_JAW_HALF_TARGET, .0007)
        self.assertAlmostEqual(2*(C.CUBE_JAW_HALF_TARGET+C.CONTACT_INNER_OFFSET), .0094)

    def test_mirrored_exports(self):
        for part in ('support', 'pad'):
            left, _ = load_stl('L', part)
            right, _ = load_stl('R', part)
            self.assertEqual({(x,-y,z) for x,y,z in left}, set(right))

if __name__ == '__main__':
    unittest.main()
