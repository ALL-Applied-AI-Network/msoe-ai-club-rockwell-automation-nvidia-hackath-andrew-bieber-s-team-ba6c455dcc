# Flat padded fingers: installation and validation

Extract this ZIP into a NEW directory on Rosie. Keep your original project as a
backup. Run commands inside the extracted fanuc_er4ia_sim directory. Use your
existing Isaac Python interpreter; bootstrap prepares only the host environment.

```bash
./bootstrap.sh
"$HOME/venvs/isaac-check/bin/python" build_scene.py
```

That interpreter path was used in your earlier Rosie setup. If it no longer
exists, use the actual Isaac interpreter from your current session. Alternatively,
if ISAAC points to an Isaac installation, use "$ISAAC/python.sh" build_scene.py.

For a headless saved scene:

```bash
mkdir -p runs
"$HOME/venvs/isaac-check/bin/python" build_scene.py --headless --save runs/flat_scene.usd
```

## What changed

- FLAT_PADDED_FINGERS=True in scene_config.py selects the new geometry.
- Four original binary STL exports are bundled in assets/gripper. Runtime converts
  millimetres to metres once, preserving the part origin and adding only the
  existing axial finger mount offset. The right support filename is normalized.
- Each jaw has two visual meshes and three exact box contact proxies: proximal
  support, distal support, pad. No convex hull bridges the step. The old hooks,
  detailed finger visuals, cosmetic fasteners, sensor carrier and tape are skipped
  in flat mode. Jaw carriage, joints, drives and camera remain as before.
- Pads inherit the existing soft-tip friction estimate (static 1.5, dynamic 1.3).
  They are rigid contacts, not deformable rubber. No extra pad rigid bodies.
- Jaw travel stays 6 mm each. Distal contact gap is 20 mm open and 8 mm closed.
  Existing straight_face_gap/open_gap fields retain their legacy actuator-reference
  meaning (12 mm open); new contact gap metadata describes the actual pads.
- The cube closing target accounts for the new pad offset. Existing conservative
  object eligibility gates remain; this does not enable new cap/vial sorting.
- Sort plans record finger design. Old plans are rejected; recapture and replan.
- Set FLAT_PADDED_FINGERS=False to rebuild with legacy hooked fingers.

## Verification performed here

33 existing host tests and four added geometry tests passed. The added tests check
STL volume against box-proxy union, vertices within the proxies, mirrored exports,
pad/support contact, jaw gap and cube closure target. Python compilation passed.
No Isaac Sim, PhysX execution, robot asset loading, GPU capture or Cosmos model
validation was possible in the editing environment. Previous six-cube success
claims in the original documentation do not validate this modification.

## Next checks on Rosie

1. Build a fresh scene. Confirm both flat pads face inward and old hooks are absent.
   Inspect collision visualization: three finger boxes plus the existing carriage
   per jaw; no hook colliders. Check the fully open gap is 20 mm.
2. Test a single 17 mm vial using your existing diagnostic. Keep contact within the
   distal 32 mm pad region, clear of the shoulder. At centered first contact each
   jaw moves about 1.5 mm inward from fully open. The 8 mm closed gap is a travel
   limit, not a desired vial diameter; do not interpret full-close position control
   as a calibrated grip force. Existing drive force settings are unchanged.
3. Record jaw positions and vial height through RELEASE, SETTLE and RETREAT.
   Confirm the vial stays on the table after retreat before claiming the fix works.
   The uploaded starter lacks your custom release diagnostic, so retain that file
   separately and run it against this updated builder.
4. Recapture/replan before testing the six-cube task. Follow SETUP.md and require
   six verified pickups/placements and task_complete=true in execution_report.json.

The 20 mm opening does not admit a 20.83 mm cap plug or a 31.75 mm flange head-on.
Other approach/grasp strategies require separate validation. Physical mounting
holes, pad bonding, finger strength and real friction have not been validated.
