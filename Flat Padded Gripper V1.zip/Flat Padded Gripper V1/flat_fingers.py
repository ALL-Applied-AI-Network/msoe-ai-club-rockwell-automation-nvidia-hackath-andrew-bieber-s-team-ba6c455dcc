"""SolidWorks binary STL visuals and matching box proxies (runtime metres)."""
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent / 'assets' / 'gripper'


def load_stl(tag, part):
    if tag not in ('L', 'R') or part not in ('support', 'pad'):
        raise ValueError('Expected L/R and support/pad')
    data = (ROOT / f'jaw_{tag}_{part}_mm.stl').read_bytes()
    count = struct.unpack_from('<I', data, 80)[0]
    if len(data) != 84 + 50 * count:
        raise ValueError('Expected a binary STL')
    points = []
    for i in range(count):
        row = struct.unpack_from('<12fH', data, 84 + i * 50)
        points.extend(tuple(v * 0.001 for v in row[k:k+3]) for k in (3, 6, 9))
    return points, list(range(len(points)))


def collider_boxes(tag):
    """Exact union for the uploaded stepped solids; no hull across the recess."""
    if tag not in ('L', 'R'):
        raise ValueError('Expected L/R')
    sign = 1 if tag == 'L' else -1
    return (
        ('Base', (0.044, 0.012, 0.006), (0.022, 0, 0)),
        ('DistalSupport', (0.032, 0.007, 0.006), (0.060, sign * 0.0025, 0)),
        ('Pad', (0.032, 0.001, 0.006), (0.060, -sign * 0.0015, 0)),
    )
